package com.mikeki.camerastabilizer;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.SurfaceTexture;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureFailure;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Stabilizer Lab 1.0.0: public Camera2 OIS/EIS mode requests, sensor diagnostics,
 * and Xiaomi CIT instructions. Does NOT perform OEM camera module calibration.
 */
public final class MainActivity extends Activity implements SensorEventListener {
    private static final int REQ_CAMERA = 1001;
    private static final int MODE_OFF = 0;
    private static final int MODE_OIS = 1;
    private static final int MODE_EIS = 2;
    private static final int BG = 0xFF0B101A;
    private static final int PANEL = 0xFF172132;
    private static final int SECONDARY = 0xFF9BAEC4;
    private static final int TEXT = 0xFFF1F5FC;
    private static final int ACCENT = 0xFF6BA8FF;
    private static final int EDGE = 0xFF293B54;
    private static final String CIT_CODE = "*#*#6484#*#*";

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final SensorStabilityAnalyzer motionAnalyzer = new SensorStabilityAnalyzer();
    private final List<String> cameraIds = new ArrayList<>();

    private CameraManager cameraManager;
    private CameraCharacteristics characteristics;
    private SensorManager sensorManager;
    private Sensor gyro, accelerometer;
    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private CameraDevice cameraDevice;
    private CameraCaptureSession captureSession;
    private Surface previewSurface;
    private TextureView textureView;
    private Spinner cameraSpinner;
    private TextView status, supportedModes, activeModes, sensorReading, testResult, deviceInfo, caption;
    private Button permissionButton, offButton, oisButton, eisButton, testButton;
    private int currentMode = MODE_OFF;
    private String selectedCameraId;
    private int cameraGeneration = 0;
    private boolean supportsOis = false;
    private boolean supportsEis = false;
    private boolean supportsPreviewEis = false;
    private boolean testRunning = false;
    private long lastCaptureUiMillis = 0L;
    private long lastSensorUiMillis = 0L;
    private float latestGyroX, latestGyroY, latestGyroZ;
    private float latestAccelX, latestAccelY, latestAccelZ;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        gyro = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        cameraThread = new HandlerThread("StabilizerCamera");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());
        buildUi();
        refreshCameraList();
    }

    private void buildUi() {
        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(true);
        scroller.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(28));
        scroller.addView(root);
        setContentView(scroller);

        TextView brand = label("STABILIZER LAB  •  v1.0", 11, ACCENT, true);
        root.addView(brand);
        TextView title = label("ตรวจระบบกันสั่นกล้อง", 25, TEXT, true);
        addTopMargin(root, title, 7);
        TextView description = label("ทดสอบ OIS / EIS / Gyroscope ด้วย API ของ Android", 13, SECONDARY, false);
        addTopMargin(root, description, 5);

        LinearLayout cameraCard = panel();
        addTopMargin(root, cameraCard, 17);
        cameraCard.addView(label("กล้องที่ต้องการทดสอบ", 14, TEXT, true));
        cameraSpinner = new Spinner(this);
        LinearLayout.LayoutParams spinnerParams = new LinearLayout.LayoutParams(-1, dp(46));
        spinnerParams.topMargin = dp(5);
        cameraCard.addView(cameraSpinner, spinnerParams);
        cameraSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position >= 0 && position < cameraIds.size()) {
                    String newCamera = cameraIds.get(position);
                    if (!newCamera.equals(selectedCameraId)) {
                        selectedCameraId = newCamera;
                        loadCapabilities();
                        closeCamera();
                        openCamera();
                    }
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        status = label("กำลังตรวจสอบกล้อง...", 13, SECONDARY, false);
        addTopMargin(cameraCard, status, 8);
        supportedModes = label("OIS: ?   •   EIS: ?", 13, SECONDARY, false);
        addTopMargin(cameraCard, supportedModes, 5);
        permissionButton = button("อนุญาตให้ใช้กล้อง", true);
        addTopMargin(cameraCard, permissionButton, 9);
        permissionButton.setOnClickListener(v -> requestCameraPermission());

        LinearLayout previewCard = panel();
        addTopMargin(root, previewCard, 12);
        previewCard.addView(label("ภาพจากกล้องแบบเรียลไทม์", 14, TEXT, true));
        FrameLayout previewFrame = new FrameLayout(this);
        previewFrame.setBackgroundColor(0xFF02050A);
        LinearLayout.LayoutParams previewFrameParams = new LinearLayout.LayoutParams(-1, dp(215));
        previewFrameParams.topMargin = dp(9);
        previewCard.addView(previewFrame, previewFrameParams);
        textureView = new TextureView(this);
        previewFrame.addView(textureView, new FrameLayout.LayoutParams(-1, -1));
        textureView.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) { openCamera(); }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) { }
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) { closeCamera(); return true; }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture surface) { }
        });
        TextView previewNote = label("บางรุ่นใช้ EIS เฉพาะตอนบันทึกวิดีโอ หรือจำกัดบางความละเอียด", 11, SECONDARY, false);
        addTopMargin(previewCard, previewNote, 7);

        LinearLayout modeCard = panel();
        addTopMargin(root, modeCard, 12);
        modeCard.addView(label("โหมดทดสอบกันสั่น", 14, TEXT, true));
        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams modeParams = new LinearLayout.LayoutParams(-1, dp(44));
        modeParams.topMargin = dp(10);
        modeCard.addView(modeRow, modeParams);
        offButton = button("OFF", true);
        oisButton = button("OIS", false);
        eisButton = button("EIS", false);
        for (Button b : Arrays.asList(offButton, oisButton, eisButton)) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, 1f);
            p.setMargins(dp(2), 0, dp(2), 0);
            modeRow.addView(b, p);
        }
        offButton.setOnClickListener(v -> setMode(MODE_OFF));
        oisButton.setOnClickListener(v -> setMode(MODE_OIS));
        eisButton.setOnClickListener(v -> setMode(MODE_EIS));
        activeModes = label("สถานะที่กล้องรายงาน: รอเปิดกล้อง", 12, SECONDARY, false);
        addTopMargin(modeCard, activeModes, 10);
        caption = label("การเลือกโหมดเป็นคำสั่งผ่าน Camera2 ไม่ใช่การปรับเทียบฮาร์ดแวร์", 11, SECONDARY, false);
        addTopMargin(modeCard, caption, 7);

        LinearLayout sensorCard = panel();
        addTopMargin(root, sensorCard, 12);
        sensorCard.addView(label("เซ็นเซอร์การเคลื่อนไหว", 14, TEXT, true));
        sensorReading = label("กำลังอ่าน Gyroscope / Accelerometer...", 13, SECONDARY, false);
        addTopMargin(sensorCard, sensorReading, 9);
        testButton = button("ทดสอบความนิ่ง 3 วินาที", true);
        addTopMargin(sensorCard, testButton, 12);
        testButton.setOnClickListener(v -> testMotion());
        testResult = label("วางโทรศัพท์บนโต๊ะราบก่อนทดสอบ เพื่อวัดการเคลื่อนไหวพื้นฐานของเซ็นเซอร์", 12, SECONDARY, false);
        addTopMargin(sensorCard, testResult, 9);

        LinearLayout toolCard = panel();
        addTopMargin(root, toolCard, 12);
        toolCard.addView(label("เครื่องมือ Xiaomi", 14, TEXT, true));
        deviceInfo = label("เครื่อง: " + Build.MANUFACTURER + " " + Build.MODEL + "  •  Android " + Build.VERSION.RELEASE, 12, SECONDARY, false);
        addTopMargin(toolCard, deviceInfo, 7);
        Button citButton = button("คัดลอกโค้ด CIT และเปิดแป้นโทร", false);
        addTopMargin(toolCard, citButton, 11);
        citButton.setOnClickListener(v -> openXiaomiCit());
        TextView citHelp = label("กด " + CIT_CODE + " ในแอปโทรศัพท์ แล้วเลือกการตรวจสอบ Camera / Gyroscope หากเครื่องมีเมนูนี้", 12, SECONDARY, false);
        addTopMargin(toolCard, citHelp, 8);
        Button shareButton = button("แชร์รายงานตรวจสอบ", false);
        addTopMargin(toolCard, shareButton, 11);
        shareButton.setOnClickListener(v -> shareReport());

        TextView disclaimer = label("หมายเหตุ: แอปไม่สามารถเขียนค่าคาลิเบรต OIS จากโรงงานหรือซ่อมโมดูลกล้องที่เสียได้ โดยไม่ใช้เครื่องมือจากผู้ผลิต", 11, SECONDARY, false);
        addTopMargin(root, disclaimer, 16);
        updateModeButtons();
    }

    private void refreshCameraList() {
        cameraIds.clear();
        List<String> labels = new ArrayList<>();
        try {
            for (String id : cameraManager.getCameraIdList()) {
                CameraCharacteristics c = cameraManager.getCameraCharacteristics(id);
                Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                String side = facing == null ? "ไม่ทราบตำแหน่ง" :
                    facing == CameraCharacteristics.LENS_FACING_BACK ? "กล้องหลัง" :
                    facing == CameraCharacteristics.LENS_FACING_FRONT ? "กล้องหน้า" : "กล้องภายนอก";
                cameraIds.add(id);
                labels.add(side + "  •  ID " + id);
            }
        } catch (Exception e) { status.setText("ไม่สามารถอ่านรายชื่อกล้อง: " + e.getMessage()); }
        if (cameraIds.isEmpty()) {
            labels.add("ไม่พบกล้องผ่าน Camera2");
            selectedCameraId = null;
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, labels);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        cameraSpinner.setAdapter(adapter);
        int preferred = 0;
        for (int i = 0; i < labels.size(); i++) {
            if (labels.get(i).contains("กล้องหลัง")) { preferred = i; break; }
        }
        if (!cameraIds.isEmpty()) {
            cameraSpinner.setSelection(preferred);
            if (selectedCameraId == null) {
                selectedCameraId = cameraIds.get(preferred);
                loadCapabilities();
                openCamera();
            }
        }
        permissionButton.setVisibility(hasCameraPermission() ? View.GONE : View.VISIBLE);
    }

    private void loadCapabilities() {
        supportsOis = supportsEis = supportsPreviewEis = false;
        if (selectedCameraId == null) return;
        try {
            characteristics = cameraManager.getCameraCharacteristics(selectedCameraId);
            int[] optical = characteristics.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION);
            int[] electronic = characteristics.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES);
            supportsOis = contains(optical, CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON);
            supportsEis = contains(electronic, CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON);
            supportsPreviewEis = Build.VERSION.SDK_INT >= 33 &&
                contains(electronic, CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION);
            supportedModes.setText("OIS: " + (supportsOis ? "รองรับ" : "ไม่เปิดเผย/ไม่รองรับ") +
                "  •  EIS: " + ((supportsEis || supportsPreviewEis) ? "รองรับ" : "ไม่เปิดเผย/ไม่รองรับ") +
                "\nEIS สำหรับพรีวิว: " + (supportsPreviewEis ? "รองรับ" : "ไม่เปิดเผย/ไม่รองรับ"));
            if (currentMode == MODE_OIS && !supportsOis ||
                currentMode == MODE_EIS && !(supportsEis || supportsPreviewEis)) {
                currentMode = MODE_OFF;
            }
        } catch (Exception e) {
            status.setText("อ่านความสามารถกล้องไม่ได้: " + e.getMessage());
        }
        updateModeButtons();
    }

    private static boolean contains(int[] values, int target) {
        if (values == null) return false;
        for (int n : values) if (n == target) return true;
        return false;
    }

    private void setMode(int mode) {
        if (mode == MODE_OIS && !supportsOis) return;
        if (mode == MODE_EIS && !(supportsEis || supportsPreviewEis)) return;
        currentMode = mode;
        updateModeButtons();
        applyRepeatingRequest();
    }

    private void updateModeButtons() {
        if (offButton == null) return;
        offButton.setBackground(pill(currentMode == MODE_OFF));
        oisButton.setBackground(pill(currentMode == MODE_OIS));
        eisButton.setBackground(pill(currentMode == MODE_EIS));
        oisButton.setEnabled(supportsOis);
        eisButton.setEnabled(supportsEis || supportsPreviewEis);
        oisButton.setAlpha(supportsOis ? 1f : 0.45f);
        eisButton.setAlpha(supportsEis || supportsPreviewEis ? 1f : 0.45f);
    }

    private void requestCameraPermission() {
        if (Build.VERSION.SDK_INT >= 23 && !hasCameraPermission()) {
            requestPermissions(new String[] {Manifest.permission.CAMERA}, REQ_CAMERA);
        } else openCamera();
    }

    private boolean hasCameraPermission() {
        return checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code != REQ_CAMERA) return;
        boolean granted = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
        permissionButton.setVisibility(granted ? View.GONE : View.VISIBLE);
        if (granted) openCamera();
        else status.setText("ต้องอนุญาตกล้องเพื่อทดลอง OIS / EIS");
    }

    private void openCamera() {
        if (selectedCameraId == null || textureView == null || !textureView.isAvailable()) return;
        if (!hasCameraPermission()) { status.setText("กดอนุญาตเพื่อเปิดภาพจากกล้อง"); return; }
        if (cameraDevice != null) return;
        final int generation = ++cameraGeneration;
        status.setText("กำลังเชื่อมต่อกล้อง ID " + selectedCameraId + "...");
        try {
            cameraManager.openCamera(selectedCameraId, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice device) {
                    if (generation != cameraGeneration || isFinishing()) { device.close(); return; }
                    cameraDevice = device;
                    startPreview(generation);
                }
                @Override public void onDisconnected(CameraDevice device) {
                    device.close();
                    if (generation == cameraGeneration) {
                        cameraDevice = null;
                        ui.post(() -> status.setText("กล้องถูกตัดการเชื่อมต่อ"));
                    }
                }
                @Override public void onError(CameraDevice device, int error) {
                    device.close();
                    if (generation == cameraGeneration) {
                        cameraDevice = null;
                        ui.post(() -> status.setText("กล้องเปิดไม่สำเร็จ (รหัส " + error + ")"));
                    }
                }
            }, cameraHandler);
        } catch (SecurityException e) {
            status.setText("ไม่ได้รับสิทธิ์กล้อง");
        } catch (Exception e) {
            status.setText("เปิดกล้องไม่สำเร็จ: " + e.getMessage());
        }
    }

    private void startPreview(int generation) {
        try {
            if (generation != cameraGeneration || cameraDevice == null || !textureView.isAvailable()) return;
            SurfaceTexture st = textureView.getSurfaceTexture();
            if (st == null) return;
            android.util.Size size = choosePreviewSize();
            st.setDefaultBufferSize(size.getWidth(), size.getHeight());
            previewSurface = new Surface(st);
            cameraDevice.createCaptureSession(Arrays.asList(previewSurface), new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession session) {
                    if (generation != cameraGeneration || cameraDevice == null) {
                        session.close(); return;
                    }
                    captureSession = session;
                    ui.post(() -> status.setText("กล้องพร้อมใช้งาน • เลือก OFF / OIS / EIS ได้"));
                    applyRepeatingRequest();
                }
                @Override public void onConfigureFailed(CameraCaptureSession session) {
                    ui.post(() -> status.setText("สร้างพรีวิวไม่ได้: กล้องปฏิเสธการตั้งค่า"));
                }
            }, cameraHandler);
        } catch (Exception e) {
            ui.post(() -> status.setText("เริ่มภาพกล้องไม่ได้: " + e.getMessage()));
        }
    }

    private android.util.Size choosePreviewSize() {
        android.util.Size fallback = new android.util.Size(640, 480);
        if (characteristics == null) return fallback;
        StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        if (map == null) return fallback;
        android.util.Size[] sizes = map.getOutputSizes(SurfaceTexture.class);
        if (sizes == null || sizes.length == 0) return fallback;
        android.util.Size best = sizes[0];
        double bestScore = Double.MAX_VALUE;
        for (android.util.Size s : sizes) {
            double pixels = (double)s.getWidth() * s.getHeight();
            if (pixels < 300000 || pixels > 2100000) continue;
            double aspect = (double)Math.max(s.getWidth(),s.getHeight()) / Math.min(s.getWidth(),s.getHeight());
            double score = Math.abs(aspect - 16.0/9.0) * 1000 + Math.abs(pixels - 921600) / 100000;
            if (score < bestScore) { best = s; bestScore = score; }
        }
        return best;
    }

    private void applyRepeatingRequest() {
        if (captureSession == null || cameraDevice == null || previewSurface == null) return;
        try {
            CaptureRequest.Builder req = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            req.addTarget(previewSurface);
            req.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO);
            req.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            int[] optical = characteristics == null ? null :
                characteristics.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION);
            int[] electronic = characteristics == null ? null :
                characteristics.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES);
            // Never request both OIS and EIS at once: Android documents interference.
            if (optical != null && optical.length > 0) {
                req.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                    currentMode == MODE_OIS && supportsOis ?
                    CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON :
                    CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_OFF);
            }
            if (electronic != null && electronic.length > 0) {
                int eisMode = CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_OFF;
                if (currentMode == MODE_EIS) {
                    if (supportsPreviewEis && Build.VERSION.SDK_INT >= 33) {
                        eisMode = CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION;
                    } else if (supportsEis) {
                        eisMode = CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON;
                    }
                }
                req.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, eisMode);
            }
            captureSession.setRepeatingRequest(req.build(), new CameraCaptureSession.CaptureCallback() {
                @Override public void onCaptureCompleted(CameraCaptureSession session, CaptureRequest request,
                                                           TotalCaptureResult result) {
                    long now = SystemClock.elapsedRealtime();
                    if (now - lastCaptureUiMillis < 700) return;
                    lastCaptureUiMillis = now;
                    Integer ois = result.get(CaptureResult.LENS_OPTICAL_STABILIZATION_MODE);
                    Integer eis = result.get(CaptureResult.CONTROL_VIDEO_STABILIZATION_MODE);
                    String optical = ois == null ? "ไม่รายงาน" :
                        ois == CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON ? "ON" : "OFF";
                    String digital = eis == null ? "ไม่รายงาน" :
                        eis == CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_OFF ? "OFF" :
                        (Build.VERSION.SDK_INT >= 33 && eis == CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION) ? "PREVIEW" : "ON";
                    ui.post(() -> activeModes.setText("ค่าที่กล้องรายงาน • OIS: " + optical + "   EIS: " + digital));
                }
                @Override public void onCaptureFailed(CameraCaptureSession session, CaptureRequest request,
                                                      CaptureFailure failure) {
                    ui.post(() -> activeModes.setText("กล้องปฏิเสธคำสั่งโหมดนี้ ลอง OFF หรือตัวอื่น"));
                }
            }, cameraHandler);
        } catch (Exception e) {
            ui.post(() -> activeModes.setText("ปรับโหมดไม่ได้: " + e.getMessage()));
        }
    }

    private void closeCamera() {
        ++cameraGeneration;
        if (captureSession != null) {
            try { captureSession.stopRepeating(); } catch (Exception ignored) { }
            captureSession.close();
            captureSession = null;
        }
        if (cameraDevice != null) { cameraDevice.close(); cameraDevice = null; }
        if (previewSurface != null) { previewSurface.release(); previewSurface = null; }
    }

    @Override protected void onResume() {
        super.onResume();
        if (gyro != null) sensorManager.registerListener(this, gyro, SensorManager.SENSOR_DELAY_GAME);
        if (accelerometer != null) sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME);
        if (hasCameraPermission()) openCamera();
    }

    @Override protected void onPause() {
        sensorManager.unregisterListener(this);
        closeCamera();
        super.onPause();
    }

    @Override protected void onDestroy() {
        closeCamera();
        cameraThread.quitSafely();
        super.onDestroy();
    }

    @Override public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
            latestGyroX = event.values[0]; latestGyroY = event.values[1]; latestGyroZ = event.values[2];
            if (testRunning) motionAnalyzer.addGyroscope(latestGyroX, latestGyroY, latestGyroZ);
        } else if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            latestAccelX = event.values[0]; latestAccelY = event.values[1]; latestAccelZ = event.values[2];
            if (testRunning) motionAnalyzer.addAccelerometer(latestAccelX, latestAccelY, latestAccelZ);
        }
        long now = SystemClock.elapsedRealtime();
        if (now - lastSensorUiMillis < 300 || sensorReading == null) return;
        lastSensorUiMillis = now;
        sensorReading.setText("Gyroscope: " + (gyro == null ? "ไม่พบเซ็นเซอร์" :
            fmt("%.3f / %.3f / %.3f rad/s", latestGyroX, latestGyroY, latestGyroZ)) +
            "\nAccelerometer: " + (accelerometer == null ? "ไม่พบเซ็นเซอร์" :
            fmt("%.2f / %.2f / %.2f m/s²", latestAccelX, latestAccelY, latestAccelZ)));
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    private void testMotion() {
        if (testRunning) return;
        if (gyro == null || accelerometer == null) {
            testResult.setText("เครื่องไม่เปิดเผยเซ็นเซอร์ Gyroscope หรือ Accelerometer ให้แอป");
            return;
        }
        motionAnalyzer.reset();
        testRunning = true;
        testButton.setEnabled(false);
        testButton.setText("กำลังเก็บข้อมูล 3 วินาที...");
        testResult.setText("โปรดวางเครื่องนิ่งบนโต๊ะระหว่างเก็บข้อมูล");
        ui.postDelayed(() -> {
            if (isFinishing()) return;
            testRunning = false;
            testButton.setEnabled(true);
            testButton.setText("ทดสอบความนิ่ง 3 วินาที");
            SensorStabilityAnalyzer.Snapshot s = motionAnalyzer.snapshot();
            if (s.gyroSamples < 10 || s.accelSamples < 10) {
                testResult.setText("ข้อมูลไม่เพียงพอ: ตรวจสอบเซ็นเซอร์หรือเริ่มใหม่อีกครั้ง");
                return;
            }
            testResult.setText((s.sufficientlyStill ? "✓ เครื่องค่อนข้างนิ่งขณะทดสอบ" : "! พบการเคลื่อนไหวหรือค่าเซ็นเซอร์เบี่ยงเบน") +
                "\nGyro RMS: " + fmt("%.4f rad/s", s.gyroRms) +
                "  •  Accel deviation RMS: " + fmt("%.3f m/s²", s.accelDeviationRms) +
                "\nตัวอย่าง: Gyro " + s.gyroSamples + " / Accel " + s.accelSamples +
                "\n*ผลนี้ไม่ยืนยันว่าโมดูล OIS ปกติหรือเสีย*");
        }, 3000L);
    }

    private void openXiaomiCit() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("Xiaomi CIT", CIT_CODE));
        Toast.makeText(this, "คัดลอกโค้ด CIT แล้ว", Toast.LENGTH_SHORT).show();
        Intent dial = new Intent(Intent.ACTION_DIAL);
        try { startActivity(dial); }
        catch (Exception e) { Toast.makeText(this, "เปิดโทรศัพท์เองแล้วกด " + CIT_CODE, Toast.LENGTH_LONG).show(); }
    }

    private void shareReport() {
        SensorStabilityAnalyzer.Snapshot s = motionAnalyzer.snapshot();
        String report = "Stabilizer Lab v1.0\n" +
            "Device: " + Build.MANUFACTURER + " " + Build.MODEL + " / Android " + Build.VERSION.RELEASE + "\n" +
            "Camera2 ID: " + (selectedCameraId == null ? "n/a" : selectedCameraId) + "\n" +
            "Camera2 OIS supported: " + supportsOis + "\n" +
            "Camera2 EIS supported: " + (supportsEis || supportsPreviewEis) + "\n" +
            "Camera2 preview stabilization: " + supportsPreviewEis + "\n" +
            "Requested mode: " + (currentMode == MODE_OIS ? "OIS" : currentMode == MODE_EIS ? "EIS" : "OFF") + "\n" +
            "Camera2 result: " + activeModes.getText() + "\n" +
            "Gyro RMS rad/s: " + (Double.isNaN(s.gyroRms) ? "not tested" : fmt("%.4f", s.gyroRms)) + "\n" +
            "Accel deviation RMS m/s2: " + (Double.isNaN(s.accelDeviationRms) ? "not tested" : fmt("%.4f", s.accelDeviationRms)) + "\n" +
            "NOTE: This is not an OEM OIS calibration or a repair diagnosis.";
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT, report);
        startActivity(Intent.createChooser(share, "แชร์รายงานกล้อง"));
    }

    private static String fmt(String format, Object... args) { return String.format(Locale.US, format, args); }
    private int dp(float value) { return (int)(getResources().getDisplayMetrics().density * value + 0.5f); }

    private TextView label(String text, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(color);
        t.setTextSize(sp);
        t.setLineSpacing(dp(2), 1.04f);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout panel() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(13), dp(13), dp(13), dp(13));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(PANEL);
        bg.setCornerRadius(dp(17));
        bg.setStroke(dp(1), EDGE);
        l.setBackground(bg);
        return l;
    }

    private Button button(String text, boolean active) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTextColor(TEXT);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(8), dp(4), dp(8), dp(4));
        b.setBackground(pill(active));
        b.setMinHeight(dp(44));
        return b;
    }

    private GradientDrawable pill(boolean active) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(active ? 0xFF255B9D : 0xFF243247);
        shape.setCornerRadius(dp(11));
        shape.setStroke(dp(1), active ? ACCENT : EDGE);
        return shape;
    }

    private void addTopMargin(LinearLayout parent, View child, int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(topDp);
        parent.addView(child, p);
    }
}
