package com.mikeki.camerastabilizer;

/** Sensor-only motion measurements, not an OIS calibration or proof of OIS health. */
public final class SensorStabilityAnalyzer {
    public static final double GRAVITY = 9.80665;
    private int gyroCount;
    private int accelCount;
    private double gyroSquareSum;
    private double accelDeviationSquareSum;

    public void reset() {
        gyroCount = accelCount = 0;
        gyroSquareSum = accelDeviationSquareSum = 0.0;
    }

    public void addGyroscope(float x, float y, float z) {
        double magnitudeSquare = (double) x * x + (double) y * y + (double) z * z;
        gyroSquareSum += magnitudeSquare;
        gyroCount++;
    }

    public void addAccelerometer(float x, float y, float z) {
        double magnitude = Math.sqrt((double)x*x + (double)y*y + (double)z*z);
        double deviation = magnitude - GRAVITY;
        accelDeviationSquareSum += deviation * deviation;
        accelCount++;
    }

    public Snapshot snapshot() {
        double gyroRms = gyroCount == 0 ? Double.NaN : Math.sqrt(gyroSquareSum / gyroCount);
        double accelRms = accelCount == 0 ? Double.NaN : Math.sqrt(accelDeviationSquareSum / accelCount);
        boolean still = gyroCount > 10 && accelCount > 10 && gyroRms < 0.05 && accelRms < 0.35;
        return new Snapshot(gyroCount, accelCount, gyroRms, accelRms, still);
    }

    public static final class Snapshot {
        public final int gyroSamples, accelSamples;
        public final double gyroRms, accelDeviationRms;
        public final boolean sufficientlyStill;
        private Snapshot(int g, int a, double gr, double ar, boolean still) {
            gyroSamples = g; accelSamples = a;
            gyroRms = gr; accelDeviationRms = ar; sufficientlyStill = still;
        }
    }
}
