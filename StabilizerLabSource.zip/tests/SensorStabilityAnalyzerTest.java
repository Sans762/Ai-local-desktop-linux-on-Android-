import com.mikeki.camerastabilizer.SensorStabilityAnalyzer;

public class SensorStabilityAnalyzerTest {
    public static void main(String[] args) {
        SensorStabilityAnalyzer a = new SensorStabilityAnalyzer();
        if (!Double.isNaN(a.snapshot().gyroRms)) throw new AssertionError("empty should be NaN");
        for (int i = 0; i < 100; i++) {
            a.addGyroscope(0.001f, 0.002f, 0.003f);
            a.addAccelerometer(0f, 0f, 9.80665f);
        }
        if (!a.snapshot().sufficientlyStill) throw new AssertionError("stationary sample expected stable");
        a.reset();
        for (int i = 0; i < 100; i++) {
            a.addGyroscope(1.2f, 0.5f, 0.2f);
            a.addAccelerometer(7f, 7f, 7f);
        }
        if (a.snapshot().sufficientlyStill) throw new AssertionError("moving sample expected unstable");
        a.reset();
        for (int i = 0; i < 100; i++) a.addGyroscope(0f,0f,0f);
        if (a.snapshot().sufficientlyStill) throw new AssertionError("missing accelerometer should be unknown");
        System.out.println("PASS: 4 sensor analyzer checks");
    }
}
